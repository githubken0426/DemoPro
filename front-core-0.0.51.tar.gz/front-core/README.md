# Neobank Core

frontend core module for Neobank.

- [angular7.1](https://angular.io/) Javascript Framework from Google inc.
- [karma](https://github.com/karma-runner/karma) Test Runner.
- [jasmine](https://jasmine.github.io/) Unit testing.
- [protractor](http://www.protractortest.org/) e2e testing.

## Libraries

- [ionic4](http://ionicframework.com/) HTML5/CSS3 Mobile UI Framework, powered by Angular.
- [akita](https://github.com/datorama/akita) State management.
- [date-fns](https://date-fns.org/) Date utils.
- [ngx-translate](https://github.com/ngx-translate/core) i18n support.
- [apex-charts](https://github.com/apexcharts/apexcharts.js) charts library.
- [angularfire2](https://github.com/angular/angularfire2) Firebase utils.
- [flex-layout](https://github.com/angular/flex-layout) flex-layout Framework.

## Installation

First, [angular-cli](https://github.com/angular/angular-cli) using [npm](https://www.npmjs.com/) (we assume you have pre-installed [node.js](https://nodejs.org/)).

_node.js is targeted at version 10.15.x._

```bash
npm install -g ionic@4.12.0
npm install -g @angular/cli@7.2.1
npm install -g @datorama/akita-cli@3.0.1
```

## Local develop environment

- [VisualStudioCode](https://code.visualstudio.com/)
- [Chrome](https://www.google.com/intl/ja_ALL/chrome/)
- [redux-devtools](https://chrome.google.com/webstore/detail/redux-devtools/lmhkpmbekcpmknklioeibfkpmmfibljd?hl=ja)

### VSCode plug-ins

- [Angular v7 TypeScript Snippets](https://marketplace.visualstudio.com/items?itemName=johnpapa.Angular2)
- [TSLint](https://marketplace.visualstudio.com/items?itemName=ms-vscode.vscode-typescript-tslint-plugin)
- [Stylelint](https://marketplace.visualstudio.com/items?itemName=shinnn.stylelint)
- [Prettier Javascript/Typescript/SCSS/Json formatter](https://marketplace.visualstudio.com/items?itemName=esbenp.prettier-vscode)
- [document this](https://marketplace.visualstudio.com/items?itemName=joelday.docthis)
- [Chrome Debugger](https://marketplace.visualstudio.com/items?itemName=msjsdiag.debugger-for-chrome)
- [Editorconfig sync plugin](https://marketplace.visualstudio.com/items?itemName=EditorConfig.EditorConfig)
- [IntelliSense for CSS, SCSS](https://marketplace.visualstudio.com/items?itemName=gencer.html-slim-scss-css-class-completion)
- [TypeScript Import Sorter](https://marketplace.visualstudio.com/items?itemName=mike-co.import-sorter)

### Code Formatter

```text
On Windows Shift + Alt + F
On Mac     Shift + Option + F
```

## Create .npmc

All npm is managed by Nexus.
Create npmrc to access Nexus of this network with the following command.

```bash
npm run create-npmrc <username> <password> <email>
```

## Publish

### Versioning

Set the tag with patch in the repository. Use git command.

```bash
git version --patch
```

### Publish

Publish with the npm command.

Be sure to connect to the Accenture VPN and make sure that .npmc is created.

```bash
npm publish
```

## Testing

### Unit Tests

To run the tests, run `npm test`.

### Unit Tests for CI Tool

To run the tests, run `npm run test-ci`.

The test is executed in HeadlessChrome.

The coverage report is output as follows. This is an Istanbul compatible report.

```text
coverage/lcov.info
```

The result of the unit test is output as follows. This is an Junit compatible report.

```text
reports/test-results.xml
```

## Document generation

## Project Structure

```bash

```
